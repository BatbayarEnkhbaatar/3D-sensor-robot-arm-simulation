#include "etherfunc_impl.h"
#include "etherfunc_msg.h"

#include <iostream>

using namespace std;

CRobotControllerImpl::CRobotControllerImpl()
{
}

CRobotControllerImpl::~CRobotControllerImpl()
{

}

int CRobotControllerImpl::Init(string host, int16_t port)
{
	shared_ptr<CUdpSocket> pSock(new CUdpSocket(host, port));
	m_udpSocket1 = std::move(pSock);

	return 0;
}

void CRobotControllerImpl::SetSocketTimeout(int32_t millis) {
	m_udpSocket1->SetTimeout(millis);
}

void CRobotControllerImpl::Close(bool wsaShutdown) {

	m_udpSocket1->Close();

	if (wsaShutdown) {
		m_udpSocket1->CloseNetwork();
	}
}

int CRobotControllerImpl::ReadStatus()
{
	int result = 0;

	if (m_udpSocket1->SelectForWrite() > 0) {
		
		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		// Robot Control/Status Reading
		req->header.reserved1 = 0x03;
		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status != 0x0) {
			std::cerr << "abnormal status. " << std::endl;
			std::cerr << " service = 0x" << std::hex << (int)resp->sub_hdr.service << std::endl;
			std::cerr << " status.value = 0x" << std::hex << (int)resp->sub_hdr.status  << std::endl;
		}
	}

	return result;
}

// Read B Variable ( CommandNo=0x7A )
int CRobotControllerImpl::ReadByteValue(int16_t index, int8_t* val)
{
	int result = 0;

	if (m_udpSocket1->SelectForWrite() > 0) {

		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		req->sub_hdr.commandNo = CMD_BYTE_VARIABLE;
		req->sub_hdr.instance = index;
		req->sub_hdr.attribute = 1; // Fixed to "1"
		req->sub_hdr.service = 0x0E; // Get_Attribute_Single
		req->header.data_size = 0;

		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status == 0) {
			// Success
			int8_t* pData = (int8_t*)resp->data;
			*val = *pData;
		}
		else {
			// Abnormal 
            throw CControllerException((char*)"status=0x%x", resp->sub_hdr.status);
		}
	}

	return result;
}

// Write B Variable ( CommandNo=0x7A )
int CRobotControllerImpl::WriteByteValue(int16_t index, int8_t val)
{
	int result = 0;

	if (m_udpSocket1->SelectForWrite() > 0) {
	
		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();
	
		req->sub_hdr.commandNo = CMD_BYTE_VARIABLE;
		req->sub_hdr.instance = index;
		req->sub_hdr.attribute = 1; // Fixed to "1"
		req->sub_hdr.service = 0x10; // Set_Attribute_Single
		req->header.data_size = 1;

		PBYTE pData = (PBYTE)req->data;
		*pData = val;
	
		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;
	
		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);
	
		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}
	
	if (m_udpSocket1->SelectForRead() > 0) {
	
		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();
	
		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);
	
		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status == 0) {
			// Success
		}
		else {
			// Abnormal 
            throw CControllerException((char*)"status=0x%x", resp->sub_hdr.status);
		}
	}

	return result;
}

// Read Double word Variable ( CommandNo=0x7C )
int CRobotControllerImpl::ReadDwordValue(int32_t index, int32_t* val)
{
	int result = 0;

	if (m_udpSocket1->SelectForWrite() > 0) {

		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		req->sub_hdr.commandNo = CMD_DWORD_VARIABLE;
		req->sub_hdr.instance = index;
		req->sub_hdr.attribute = 1; // Fixed to "1"
		req->sub_hdr.service = 0x0E; // Get_Attribute_Single
		req->header.data_size = 0;

		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status == 0) {
			// Success
			int32_t* pData = (int32_t*)resp->data;
			*val = *pData;
		}
		else {
			// Abnormal 
			throw CControllerException((char*)"status=0x%x", resp->sub_hdr.status);
		}
	}

	return result;
}

// Write Double word Variable ( CommandNo=0x7C )
int CRobotControllerImpl::WriteDwordValue(int32_t index, int32_t val)
{
	int result = 0;

	if (m_udpSocket1->SelectForWrite() > 0) {

		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		req->sub_hdr.commandNo = CMD_DWORD_VARIABLE;
		req->sub_hdr.instance = index;
		req->sub_hdr.attribute = 1; // Fixed to "1"
		req->sub_hdr.service = 0x10; // Set_Attribute_Single
		req->header.data_size = 4;

		int32_t* pData = (int32_t*)req->data;
		*pData = val;

		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status == 0) {
			// Success
		}
		else {
			// Abnormal 
			throw CControllerException((char*)"status=0x%x", resp->sub_hdr.status);
		}
	}

	return result;
}

// Read P Variable (Robot Position, CommandNo=0x7F)
int CRobotControllerImpl::ReadPosValue(int16_t index, RobotCoordinate* coord)
{
	int result = 0;

	int axisType = BASE_COORDINATE; // ROBOT_COORDINATE; // PULSE; // BASE_COORDINATE;

	if (m_udpSocket1->SelectForWrite() > 0) {

		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		req->sub_hdr.commandNo = CMD_POSITION_VARIABLE;
		req->sub_hdr.instance = index;
		req->sub_hdr.attribute = 0; // 0 으로 하라고 함.
		req->sub_hdr.service = 0x01; // Get_Attribute_All
		req->header.data_size = 0;  

		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status == 0) {
			// Success
			POSITION_DATA_TYPE* posData = (POSITION_DATA_TYPE*)resp->data;
			coord->x = posData->firstCoordData;
			coord->y = posData->secondCoordData;
			coord->z = posData->thirdCoordData;
			coord->rx = posData->fourthCoordData;
			coord->ry = posData->fifthCoordData;
			coord->rz = posData->sixthCoordData;
		}
		else {
			int32_t statusCode = resp->sub_hdr.statusCode & 0x0000FFFF;

			if (resp->sub_hdr.addedStatusSize == 2) {
				// 4 bytes error code
				statusCode <<= 16;
				statusCode |= (resp->sub_hdr.padding2[0] << 8) | resp->sub_hdr.padding2[1];
			}

            throw CControllerException(resp->sub_hdr.status, statusCode, (char*)"Read Position Variable error");
		}
	}

	return result;
}

// Write P Variable (Robot Position, CommandNo=0x7F)
int CRobotControllerImpl::WritePosValue(int16_t index, RobotCoordinate* coord)
{
	int result = 0;

	int axisType = BASE_COORDINATE; // ROBOT_COORDINATE; // PULSE; // BASE_COORDINATE;

	if (m_udpSocket1->SelectForWrite() > 0) {

		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		req->sub_hdr.commandNo = CMD_POSITION_VARIABLE;
		req->sub_hdr.instance = index;
		req->sub_hdr.attribute = 0; // 0 으로 하라고 하라고 함.
		req->sub_hdr.service = 0x02; // Set_Attribute_All
		req->header.data_size = sizeof(POSITION_DATA_TYPE);

		POSITION_DATA_TYPE* posData = (POSITION_DATA_TYPE*)req->data;
		posData->dataType = axisType; // 16 : Base coordinate value
		posData->form = 0;
		posData->toolNumber = 0;
		posData->userCoordNum = 0;
		posData->extendedForm = 0;
		posData->firstCoordData = coord->x;
		posData->secondCoordData = coord->y;
		posData->thirdCoordData = coord->z;
		posData->fourthCoordData = coord->rx;
		posData->fifthCoordData = coord->ry;
		posData->sixthCoordData = coord->rz;
		posData->seventhCoordData = 0;
		posData->eighthCoordData = 0;

		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status == 0) {
			// Success
		}
		else {
			int32_t statusCode = resp->sub_hdr.statusCode & 0x0000FFFF;
		
			if (resp->sub_hdr.addedStatusSize == 2) {
				// 4 bytes error code
				statusCode <<= 16;
				statusCode |= (resp->sub_hdr.padding2[0] << 8) | resp->sub_hdr.padding2[1];
			}
				
            throw CControllerException(resp->sub_hdr.status, statusCode, (char*)"Write Position Variable error");
		}
	}

	return result;
}

// Read Robot Position (Robot Position, CommandNo=0x75)
int CRobotControllerImpl::ReadPosition(RobotCoordinate* coord)
{
	int result = 0;

	int axisType = BASE_COORDINATE; // ROBOT_COORDINATE; // PULSE; // BASE_COORDINATE;

	// control group
	// 1 : R1 to 2 : R2 … Robot(pulse value)
	//	11 : B1 to 12 : B2 … Base(pulse value)
	//	21 : S1 to 23 : : S3 … Station(pulse value)
	//	101 : R1 to 102 : R2 … Robot
	int controlGroup = 101; // Robot

	if (m_udpSocket1->SelectForWrite() > 0) {

		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		req->sub_hdr.commandNo = CMD_READ_POSITION;
		req->sub_hdr.instance = controlGroup;
		req->sub_hdr.attribute = 0; // 0 으로 하라고 함.
		req->sub_hdr.service = 0x01; // Get_Attribute_All
		req->header.data_size = 0;

		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}

		if (resp->sub_hdr.status == 0) {
			// Success
			POSITION_DATA_TYPE* posData = (POSITION_DATA_TYPE*)resp->data;
			coord->x = posData->firstCoordData;
			coord->y = posData->secondCoordData;
			coord->z = posData->thirdCoordData;
			coord->rx = posData->fourthCoordData;
			coord->ry = posData->fifthCoordData;
			coord->rz = posData->sixthCoordData;
		}
		else {
			int32_t statusCode = resp->sub_hdr.statusCode & 0x0000FFFF;

			if (resp->sub_hdr.addedStatusSize == 2) {
				// 4 bytes error code
				statusCode <<= 16;
				statusCode |= (resp->sub_hdr.padding2[0] << 8) | resp->sub_hdr.padding2[1];
			}

			throw CControllerException(resp->sub_hdr.status, statusCode, (char*)"Read Position error");
		}
	}

	return result;
}

//int CRobotControllerImpl::WriteBasePosition()
//{
//	int result = 0;
//
//	if (m_udpSocket1->SelectForWrite() > 0) {
//
//		CControlMessage message;
//		message.InitRequest();
//		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();
//
//		//req->header.data_size = 36;
//		req->header.data_size = 0;
//		req->sub_hdr.commandNo = 0x80;
//		req->sub_hdr.attribute = 2;
//		//req->sub_hdr.service = 0x0;
//		req->sub_hdr.service = 0x0E;
//
//		if (req->sub_hdr.service == 0x02) {
//			const int32_t zeroPos = 0x00700000;
//			int32_t* pData = (int32_t*)req->data;
//			*pData = 16;	pData++;
//			memcpy(pData, &zeroPos, 4); pData++;	// first axis
//			memcpy(pData, &zeroPos, 4); pData++;	// second axis
//			memcpy(pData, &zeroPos, 4); pData++;	// third axis
//			memcpy(pData, &zeroPos, 4); pData++;	// fourth axis
//			memcpy(pData, &zeroPos, 4); pData++;	// fifth axis
//			memcpy(pData, &zeroPos, 4); pData++;	// sixth axis
//			memcpy(pData, &zeroPos, 4); pData++;	// seventh axis
//			memcpy(pData, &zeroPos, 4); pData++;	// eighth axis
//		}
//
//		int hdrLen = req->header.hdr_size;
//		int dataLen = req->header.data_size;
//		int bufLen = hdrLen + dataLen;
//
//		int8_t* buf = (int8_t*)req.get();
//		int bytesWritten = m_udpSocket1->Write(buf, bufLen);
//
//		if (bytesWritten > 0) {
//			std::cout << bytesWritten << " bytes sent " << std::endl;
//		}
//	}
//
//	if (m_udpSocket1->SelectForRead() > 0) {
//
//		CControlMessage message;
//		message.InitResponse();
//		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();
//
//		int8_t* buf = (int8_t*)resp.get();
//		int bufSize = sizeof(RESPONSE_MESSAGE);
//		int bytesRead = m_udpSocket1->Read(buf, bufSize);
//
//		if (bytesRead > 0) {
//			std::cout << bytesRead << " bytes read " << std::endl;
//		}
//	}
//
//	return result;
//}
//

// Move ( movj, CommandNo=0x8a)
int CRobotControllerImpl::Move(RobotCoordinate coord, int32_t speed)
{
	int result = 0;

	//data = struct.pack('<I', robot_no)		// 1
	//	data += struct.pack('<I', station_no) // 0
	//	data += struct.pack('<I', speed_class) // 0 (percent),  1 (millimeter), 2 (degree)
	//	data += struct.pack('<I', speed)	// 250
	//	data += struct.pack('<I', coordinate)	// 17  ( 16: base, 17: robot)
	//		(410961, 165503, 321240, -1742577, -61750, 1483, 10000, 10000)
	//	data += struct.pack('<iiiiiii', pos[0], pos[1], pos[2], pos[3], pos[4], pos[5], pos[6])
	//	data += struct.pack('<I', 0)  # reserved
	//	data += struct.pack('<I', form)		// 0
	//	data += struct.pack('<I', extended_form)	// 0
	//	data += struct.pack('<I', tool_no)	// 0
	//	data += struct.pack('<I', user_coor_no)	// 0
	//	data += bytearray(36)

	//	req = FS100ReqPacket(FS100PacketHeader.HEADER_DIVISION_ROBOT_CONTROL, 0, 0x8a, move_type, 0x01, 0x02, data,
	//		len(data))

	if (m_udpSocket1->SelectForWrite() > 0) {

		CControlMessage message;
		message.InitRequest();
		shared_ptr<REQUEST_MESSAGE>	req = message.getRequest();

		req->header.data_size = 104;
		req->sub_hdr.commandNo = 0x8A;
		req->sub_hdr.instance = 1; // 1: Link absolute position operation
		req->sub_hdr.attribute = 1; // '1' fixed
		req->sub_hdr.service = 0x02;	// 0x02 : Write the data the to specified coordinate

		int32_t* pData = (int32_t*)req->data;
		*pData = 1; // robot_no
		pData++;
		*pData = 0; // station_no
		pData++;
		*pData = 0; // speed_class // 0 (percent)
		pData++;
		*pData = speed; // speed // 100
		pData++;
		*pData = 16; // 16(base), 17(robot coordiante)
		pData++;

		// RobotCoordinate coord = { 345269, 141416, 372140, -1731761, -98745, -9607 };
		*pData = coord.x;
		pData++;
		*pData = coord.y;
		pData++;
		*pData = coord.z;
		pData++;
		*pData = coord.rx;
		pData++;
		*pData = coord.ry;
		pData++;
		*pData = coord.rz;
		pData++;

		// reserved1
		*pData = 0; 
		pData++;
		// reserved2
		*pData = 0;
		pData++;

		*pData = 0;
		pData++;
		*pData = 0;
		pData++;
		*pData = 0;
		pData++;
		*pData = 0;
		pData++;

		// 18 ~ 26
		for (int i = 18; i <= 26; i++) {
			*pData = 0;
			pData++;
		}

		int hdrLen = req->header.hdr_size;
		int dataLen = req->header.data_size;
		int bufLen = hdrLen + dataLen;

		int8_t* buf = (int8_t*)req.get();
		int bytesWritten = m_udpSocket1->Write(buf, bufLen);

		if (bytesWritten > 0) {
			std::cout << bytesWritten << " bytes sent " << std::endl;
		}
	}

	if (m_udpSocket1->SelectForRead() > 0) {

		CControlMessage message;
		message.InitResponse();
		shared_ptr<RESPONSE_MESSAGE> resp = message.getResponse();

		int8_t* buf = (int8_t*)resp.get();
		int bufSize = sizeof(RESPONSE_MESSAGE);
		int bytesRead = m_udpSocket1->Read(buf, bufSize);

		if (bytesRead > 0) {
			std::cout << bytesRead << " bytes read " << std::endl;
		}
	}

	return result;
}