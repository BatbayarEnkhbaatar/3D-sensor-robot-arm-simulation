#ifndef __ETHERFUNC_IMPL_H__
#define __ETHERFUNC_IMPL_H__

#include "etherfunc_implbase.h"
#include "udpsocket.h"

#include <memory>

using namespace std;

class CRobotControllerImpl : public CRobotControllerImplBase
{
public:
	CRobotControllerImpl();
	virtual ~CRobotControllerImpl();

	virtual int Init(string host, int16_t port);

	virtual void SetSocketTimeout(int32_t millis = 10000);

	// Robot Status Read
	virtual int ReadStatus();

	// Read B Variable ( CommandNo=0x7A )
	virtual int ReadByteValue(int16_t index, int8_t* val);

	// Write B Variable ( CommandNo=0x7A )
	virtual int WriteByteValue(int16_t index, int8_t val);

	// Read Double word Variable ( CommandNo=0x7C )
	int ReadDwordValue(int32_t index, int32_t* val);

	// Write Double word Variable ( CommandNo=0x7C )
	int WriteDwordValue(int32_t index, int32_t val);

	// Read P Variable (Robot Position, CommandNo=0x7F)
	virtual int ReadPosValue(int16_t index, RobotCoordinate* coord);

	// Write P Variable (Robot Position, CommandNo=0x7F)
	virtual int WritePosValue(int16_t index, RobotCoordinate* coord);

	// Read Robot Position (Robot Position, CommandNo=0x75)
	virtual int ReadPosition(RobotCoordinate* coord);

	// Move ( movj, CommandNo=0x8a)
	int Move(RobotCoordinate coord, int32_t speed=100);

	virtual void Close(bool wsaShutdown = false);

private:
	// UDP 10040 port
	shared_ptr<CUdpSocket>		m_udpSocket1; 
};
#endif