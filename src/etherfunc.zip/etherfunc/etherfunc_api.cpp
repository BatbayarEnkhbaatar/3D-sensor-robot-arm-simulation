#include "etherfunc_api.h"
#include "etherfunc_impl.h"

CRobotController::CRobotController()
{
	this->m_controller = make_shared<CRobotControllerImpl>();
}

CRobotController::~CRobotController()
{

}

int CRobotController::Init(string host, int16_t port) {
	return this->m_controller->Init(host, port);
}

void CRobotController::Close(bool wsaShutdown) {
	this->m_controller->Close(wsaShutdown);
}

int CRobotController::ReadStatus()
{
	int		result = 0;

	result = this->m_controller->ReadStatus();

	return result;
}

// Read B Variable ( CommandNo=0x7A )
int CRobotController::ReadByteValue(int16_t index, int8_t* val)
{
	int		result = 0;

	result = this->m_controller->ReadByteValue(index, val);

	return result;
}

// Write B Variable ( CommandNo=0x7A )
int CRobotController::WriteByteValue(int16_t index, int8_t val)
{
	int		result = 0;

	result = this->m_controller->WriteByteValue(index, val);

	return result;
}

// Read Double word Variable ( CommandNo=0x7C )
int CRobotController::ReadDwordValue(int32_t index, int32_t* val)
{
	int		result = 0;

	result = this->m_controller->ReadDwordValue(index, val);

	return result;
}

// Write Double word Variable ( CommandNo=0x7C )
int CRobotController::WriteDwordValue(int32_t index, int32_t val)
{
	int		result = 0;

	result = this->m_controller->WriteDwordValue(index, val);

	return result;
}

// Read P Variable (Robot Position, CommandNo=0x7F)
int CRobotController::ReadPosValue(int16_t index, RobotCoordinate* coord)
{
	int		result = 0;

	result = this->m_controller->ReadPosValue(index, coord);

	return result;
}

// Write P Variable (Robot Position, CommandNo=0x7F)
int CRobotController::WritePosValue(int16_t index, RobotCoordinate* coord)
{
	int		result = 0;

	result = this->m_controller->WritePosValue(index, coord);

	return result;
}

// Read Robot Position (Robot Position, CommandNo=0x75)
int CRobotController::ReadPosition(RobotCoordinate* coord)
{
	int result = this->m_controller->ReadPosition(coord);
	return result;
}

// Move (movj, CommandNo=0x8A)
int CRobotController::Move(RobotCoordinate coord, int32_t speed)
{
	int result = this->m_controller->Move(coord, speed);
	return result;
}