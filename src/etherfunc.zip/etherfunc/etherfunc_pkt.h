#ifndef __ETHERFUNC_PKT_H__
#define __ETHERFUNC_PKT_H__

#include <stdint.h>
#include <iostream>
#include <sstream>
#include <string>

#define		MAX_DATA_PART_SIZE	(479)

using namespace std;

#pragma pack(push, 1)

struct _RobotCoordinate {
	int x;
	int y;
	int z;
	int rx;
	int ry;
	int rz;

	_RobotCoordinate() {
		x = y = z = rx = ry = rz = 0;
	}

	_RobotCoordinate(int x, int y, int z, int rx, int ry, int rz) {
		this->x = x;
		this->y = y;
		this->z = z;
		this->rx = rx;
		this->ry = ry;
		this->rz = rz;
	}
	_RobotCoordinate(const _RobotCoordinate& other) {
		this->x = other.x;
		this->y = other.y;
		this->z = other.z;
		this->rx = other.rx;
		this->ry = other.ry;
		this->rz = other.rz;
	}

	void dump() {
		std::cout << "(x, y, z, rx, ry, rz)  = (" <<
			std::to_string(this->x) << ", " <<
			std::to_string(this->y) << ", " <<
			std::to_string(this->z) << ", " <<
			std::to_string(this->rx) << ", " <<
			std::to_string(this->ry) << ", " <<
			std::to_string(this->rz) << ")" << std::endl;
	};
	string toString() {
		stringstream ss;
		ss << "(x, y, z, rx, ry, rz)  = (" <<
			std::to_string(this->x) << ", " <<
			std::to_string(this->y) << ", " <<
			std::to_string(this->z) << ", " <<
			std::to_string(this->rx) << ", " <<
			std::to_string(this->ry) << ", " <<
			std::to_string(this->rz) << ")";

		string str = ss.str();
		return str;
	}

	bool operator==(const struct _RobotCoordinate& rhs) {
		bool isSame = this->x == rhs.x
			&& this->y == rhs.y
			&& this->z == rhs.z
			&& this->rx == rhs.rx
			&& this->ry == rhs.ry
			&& this->rz == rhs.rz;

		return isSame;
	}

};
typedef struct _RobotCoordinate RobotCoordinate;

typedef struct {
	float x, y, z;
	float rx, ry, rz;
} RobotCoordinateF;

typedef struct {
	int32_t	identifier;
	int16_t	hdr_size;
	int16_t	data_size;
	int8_t	reserved1;
	int8_t	processingDivision;
	int8_t	ack;
	int8_t	requestId;
	int32_t	blockNo;
	int8_t	reserved2[8];
} FIXED_HEADER;

typedef struct {
	int16_t	commandNo;
	int16_t	instance;
	int8_t	attribute;
	int8_t	service;
	int8_t	padding[2];
} REQUEST_SUB_HEADER;

typedef struct {
	int8_t	service;
	int8_t	status;
	int8_t	addedStatusSize;
	int8_t	padding;
	int16_t	statusCode;
	int8_t	padding2[2];
} RESPONSE_SUB_HEADER;

typedef struct {
	FIXED_HEADER	header;
	REQUEST_SUB_HEADER sub_hdr;
	int8_t	data[MAX_DATA_PART_SIZE];
} REQUEST_MESSAGE;

typedef struct {
	FIXED_HEADER	header;
	RESPONSE_SUB_HEADER sub_hdr;
	int8_t data[MAX_DATA_PART_SIZE];
} RESPONSE_MESSAGE;

typedef struct {
	int32_t	dataType;
	int32_t	form;
	int32_t	toolNumber;
	int32_t	userCoordNum;
	int32_t	extendedForm;
	int32_t	firstCoordData;
	int32_t	secondCoordData;
	int32_t	thirdCoordData;
	int32_t	fourthCoordData;
	int32_t	fifthCoordData;
	int32_t	sixthCoordData;
	int32_t	seventhCoordData;
	int32_t	eighthCoordData;
} POSITION_DATA_TYPE;

#pragma pack(pop)

#endif