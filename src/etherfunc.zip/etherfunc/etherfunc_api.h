#ifndef __ETHERFUNC_API_H__
#define __ETHERFUNC_API_H__

#include "etherfunc_defs.h"

#include <string>
#include <memory>
#include "etherfunc_implbase.h"
#include "etherfunc_pkt.h"

#include <stdarg.h>

using namespace std;

class __ETHERFUNC_API__ CRobotController
{
public:
	CRobotController();
	virtual ~CRobotController();

	int Init(string host, int16_t port);

	// default timeout = 10 secs
	void SetSocketTimeout(int32_t millis = 10000);

	// Robot Status Read
	int ReadStatus();

	// Read B Variable ( CommandNo=0x7A )
	int ReadByteValue(int16_t index, int8_t* val);

	// Write B Variable ( CommandNo=0x7A )
	int WriteByteValue(int16_t index, int8_t val);

	// Read Double word Variable ( CommandNo=0x7C )
	int ReadDwordValue(int32_t index, int32_t* val);

	// Write Double word Variable ( CommandNo=0x7C )
	int WriteDwordValue(int32_t index, int32_t val);

	// Read P Variable (Robot Position, CommandNo=0x7F)
	int ReadPosValue(int16_t index, RobotCoordinate* coord);

	// Write P Variable (Robot Position, CommandNo=0x7F)
	int WritePosValue(int16_t index, RobotCoordinate* coord);

	// Read Robot Position (Robot Position, CommandNo=0x75)
	int ReadPosition(RobotCoordinate* coord);

	// Move ( movj, CommandNo=0x8a)
	int Move(RobotCoordinate coord, int32_t speed=100);

	void Close(bool wsaShutdown = false);

private:

	shared_ptr<CRobotControllerImplBase>	m_controller;
};
#endif