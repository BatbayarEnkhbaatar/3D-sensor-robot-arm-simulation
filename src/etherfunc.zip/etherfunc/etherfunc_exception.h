#ifndef __ETHERFUNC_EXCEPTION_H__
#define __ETHERFUNC_EXCEPTION_H__

#include "etherfunc_defs.h"
#include <stdarg.h>
#include <exception>
#include <string>
#include <iostream>

using namespace std;

class __ETHERFUNC_API__ CControllerException : std::exception
{
public:
	CControllerException() {}
	CControllerException(string msg) : m_message(msg) {}
	CControllerException(char* fmt, ...) {

		char buf[1024];

		va_list ap;

		va_start(ap, fmt);
		vsnprintf(buf, sizeof(buf), fmt, ap);
		va_end(ap);

		this->m_message = buf;
	}

	CControllerException(int8_t status, int32_t statusCode, char* fmt, ...) {

		char buf[1024] = { 0 };
		char buf2[1024] = { 0 };

		va_list ap;

		va_start(ap, fmt);
		vsnprintf(buf, sizeof(buf), fmt, ap);
		va_end(ap);

		string statusMessage = getStatusMessage(statusCode);

		sprintf(buf2, "status=0x%x, code=0x%x, msg=%s, description=%s", 
				status, statusCode, statusMessage.c_str(), buf);

		this->m_message = buf2;
	}

	char* what() {
		return (char*)this->m_message.c_str();
	}

protected:

	string		getStatusMessage(int32_t statusCode) {
		switch (statusCode) {
		case 0x1010:
			return std::string("Command error");
		case 0x1011:
			return std::string("Error in number of command operands");
		case 0x1012:
			return std::string("Command operand value range over");
		case 0x1013:
			return std::string("Command operand length error");
		case 0x1020:
			return std::string("Disk full of files");
		case 0x2010:
			return std::string("Manipulator operating");
		case 0x2020:
			return std::string("Hold by programming pendant");
		case 0x2030:
			return std::string("Hold by playback panel");
		case 0x2040:
			return std::string("External hold");
		case 0x2050:
			return std::string("Command hold");
		case 0x2060:
			return std::string("Error / alarm occurring");
		case 0x2070:
			return std::string("Servo OFF");
		case 0x2080:
			return std::string("Incorrect mode");
		case 0x2090:
			return std::string("File accessing by other function");
		case 0x2100:
			return std::string("Command remote not set");
		case 0x2110:
			return std::string("This data cannot be accessed");
		case 0x2120:
			return std::string("This data cannot be loaded");
		case 0x2130:
			return std::string("Editing");
		case 0x2150:
			return std::string("Running the coordinate conversion function");
		case 0x3010:
			return std::string("Turn ON the servo power");
		case 0x3040:
			return std::string("Perform home positioning");
		case 0x3050:
			return std::string("Confirm positions");
		case 0x3070:
			return std::string("Current value not made");
		case 0x3220:
			return std::string("Panel lock; mode / cycle prohibit signal is ON");
		case 0x3230:
			return std::string("Panel lock; start prohibit signal is ON");
		case 0x3350:
			return std::string("User coordinate is not taught");
		case 0x3360:
			return std::string("User coordinate is destroyed");
		case 0x3370:
			return std::string("Incorrect control group");
		case 0x3380:
			return std::string("Incorrect base axis data");
		case 0x3390:
			return std::string("Relative job conversion prohibited(at CVTRJ)");
		case 0x3400:
			return std::string("Master job call prohibited(parameter)");
		case 0x3410:
			return std::string("Master job call prohibited (lamp ON during operation");
		case 0x3420:
			return std::string("Master job call prohibited(teach lock)");
		case 0x3430:
			return std::string("Robot calibration data not defined");
		case 0x3450:
			return std::string("Servo power cannot be turned ON");
		case 0x3460:
			return std::string("Coordinate system cannot be set");
		case 0x4010:
			return std::string("Insufficient memory capacity(job registered memory)");
		case 0x4012:
			return std::string("Insufficient memory capacity (position data registered memory)");
		case 0x4020:
			return std::string("Job editing prohibited");
		case 0x4030:
			return std::string("Same job name exists");
		case 0x4040:
			return std::string("No specified job");
		case 0x4060:
			return std::string("Set an execution job");
		case 0x4120:
			return std::string("Position data is destroyed");
		case 0x4130:
			return std::string("Position data not exist");
		case 0x4140:
			return std::string("Incorrect position variable type");
		case 0x4150:
			return std::string("END instruction for job which is not master job");
		case 0x4170:
			return std::string("Instruction data is destroyed");
		case 0x4190:
			return std::string("Invalid character in job name");
		case 0x4200:
			return std::string("Invalid character in the label name");
		case 0x4230:
			return std::string("Invalid instruction in this system");
		case 0x4420:
			return std::string("No step in job to be converted");
		case 0x4430:
			return std::string("Already converted");
		case 0x4480:
			return std::string("Teach user coordinate");
		case 0x4490:
			return std::string("Relative job / independent control function not permitted");
		case 0x5110:
			return std::string("Syntax error(syntax of instruction)");
		case 0x5120:
			return std::string("Position data error");
		case 0x5130:
			return std::string("No NOP or END");
		case 0x5170:
			return std::string("Format error(incorrect format)");
		case 0x5180:
			return std::string("Incorrect number of data");
		case 0x5200:
			return std::string("Data range over");
		case 0x5310:
			return std::string("Syntax error(except instruction)");
		case 0x5340:
			return std::string("Error in pseudo instruction specification");
		case 0x5370:
			return std::string("Error in condition file data record");
		case 0x5390:
			return std::string("Error in JOB data record");
		case 0x5430:
			return std::string("System data not same");
		case 0x5480:
			return std::string("Incorrect welding function type");
		case 0x6010:
			return std::string("The robot / station is under the operation");
		case 0x6020:
			return std::string("Not enough memory of the specified device");
		case 0x6030:
			return std::string("Cannot be accessed to the specified device");
		case 0x6040:
			return std::string("Unexpected auto backup request");
		case 0x6050:
			return std::string("CMOS size is over the RAM area");
		case 0x6060:
			return std::string("No memory allocation at the power supply on");
		case 0x6070:
			return std::string("Accessing error to backup file information");
		case 0x6080:
			return std::string("Failed in sorting backup file(Remove)");
		case 0x6090:
			return std::string("Failed in sorting backup file(Rename)");
		case 0x6100:
			return std::string("Drive name exceeds the specified values");
		case 0x6110:
			return std::string("Incorrect device");
		case 0x6120:
			return std::string("System error");
		case 0x6130:
			return std::string("Auto backup is not available");
		case 0x6140:
			return std::string("Cannot be backed up under the auto backup");
		case 0xA000:
			return std::string("Undefined command");
		case 0xA001:
			return std::string("Instance error");
		case 0xA002:
			return std::string("Attribute error");
		case 0xA101:
			return std::string("Replying data part size error(hardware limit)");
		case 0xB001:
			return std::string("Replying data part size error(software limit)");
		case 0xB002:
			return std::string("Data use prohibited");
		case 0xB003:
			return std::string("Requiring data size error");
		case 0xB004:
			return std::string("Outside the data");
		case 0xB005:
			return std::string("Data undefined");
		case 0xB006:
			return std::string("Specified application unregistered");
		case 0xB007:
			return std::string("Specified type unregistered");
		case 0xB008:
			return std::string("Control group setting error");
		case 0xB009:
			return std::string("Speed setting error");
		case 0xB00A:
			return std::string("Operating speed is not setting");
		case 0xB00B:
			return std::string("Operation coordinate system setting error");
		case 0xB00C:
			return std::string("Type setting error");
		case 0xB00D:
			return std::string("Tool No.setting error");
		case 0xB00E:
			return std::string("User No.setting error");
		case 0xC001:
			return std::string("Address error");
		case 0xC002:
			return std::string("System error");
		case 0xC003:
			return std::string("System error");
		case 0xC800:
			return std::string("System error");
		case 0xCFFF:
			return std::string("Other error");
		case 0xE2B3:
			return std::string("File not found");
		case 0xE24F:
			return std::string("Parameter setting wrongcase ");
		default:
			return std::string("errcode=") + std::to_string(statusCode);
		}
	}

	string		m_message;
};

#endif