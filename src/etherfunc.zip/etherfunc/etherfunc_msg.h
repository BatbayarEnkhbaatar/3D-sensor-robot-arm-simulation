#ifndef __ETHERFUNC_MSG_H__
#define	__ETHERFUNC_MSG_H__

#include <memory>
#include <mutex>

#include "etherfunc_pkt.h"

using namespace std;

typedef enum {
	CMD_STATUS_INFO = 0x72,
	CMD_BYTE_VARIABLE = 0x7A,
	CMD_DWORD_VARIABLE = 0x7C,
	CMD_POSITION_VARIABLE = 0x7F,
	CMD_READ_POSITION = 0x75
} ControlCommandType;

typedef enum {
	PULSE = 0,
	BASE_COORDINATE = 16,
	ROBOT_COORDINATE = 17,
	USER_COORDINATE = 18,
	TOOL_COORDINATE = 19
} ControlAxisType;
class CControlMessage
{
public:
	CControlMessage() {}
	~CControlMessage() {}

	void InitRequest();
	void InitResponse();

	shared_ptr<REQUEST_MESSAGE>		getRequest() {
		return this->m_request;
	}
	shared_ptr<RESPONSE_MESSAGE>	getResponse() {
		return this->m_response;
	}

	static std::mutex lock;
	static uint8_t REQ_ID;
	static uint8_t getReqId() {
		lock.lock();
		uint8_t id = REQ_ID++;
		lock.unlock();
		return id;
	}

private:
	shared_ptr<REQUEST_MESSAGE>		m_request;
	shared_ptr<RESPONSE_MESSAGE>	m_response;
};
#endif