#ifndef __ETHERFUNC_DEFS_H__
#define __ETHERFUNC_DEFS_H__

#ifdef __ETHERFUNC_EXPORT__
#define __ETHERFUNC_API__	__declspec(dllexport)
#else
#define __ETHERFUNC_API__	__declspec(dllimport)
#endif

#endif
