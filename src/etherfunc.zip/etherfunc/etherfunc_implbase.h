#ifndef __ETHERFUNCIMPLBASE_API_H__
#define __ETHERFUNCIMPLBASE_API_H__

#include "etherfunc_defs.h"
#include "etherfunc_pkt.h"

#include <string>
using namespace std;

class __ETHERFUNC_API__ CRobotControllerImplBase
{
public:
	CRobotControllerImplBase() {};
	virtual ~CRobotControllerImplBase() {};

	virtual int Init(string host, int16_t port) = 0;

	virtual void SetSocketTimeout(int32_t millis = 10000) = 0;

	// Robot Status Read
	virtual int ReadStatus() = 0;

	// Read B Variable ( CommandNo=0x7A )
	virtual int ReadByteValue(int16_t index, int8_t* val) = 0;

	// Write B Variable ( CommandNo=0x7A )
	virtual int WriteByteValue(int16_t index, int8_t val) = 0;

	// Read Double word Variable ( CommandNo=0x7C )
	virtual int ReadDwordValue(int32_t index, int32_t* val) = 0;

	// Write Double word Variable ( CommandNo=0x7C )
	virtual int WriteDwordValue(int32_t index, int32_t val) = 0;

	// Read P Variable (Robot Position, CommandNo=0x7F)
	virtual int ReadPosValue(int16_t index, RobotCoordinate* coord) = 0;

	// Write P Variable (Robot Position, CommandNo=0x7F)
	virtual int WritePosValue(int16_t index, RobotCoordinate* coord) = 0;

	// Read Robot Position (Robot Position, CommandNo=0x75)
	virtual int ReadPosition(RobotCoordinate* coord) = 0;

	// Move ( movj, CommandNo=0x8a)
	virtual int Move(RobotCoordinate coord, int32_t speed) = 0;

	virtual void Close(bool wsaShutdown = false) = 0;
};

#endif