#include "etherfunc_msg.h"

std::mutex CControlMessage::lock;
uint8_t CControlMessage::REQ_ID = 0;

void CControlMessage::InitRequest()
{
	const char* reserved2 = "99999999";

	this->m_request = make_shared<REQUEST_MESSAGE>();

	this->m_request->header.identifier = *((int32_t*)"YERC");
	this->m_request->header.hdr_size = 0x20; // 32bytes
	this->m_request->header.data_size = 0x0;
	this->m_request->header.reserved1 = 3;
	this->m_request->header.processingDivision = 1; 
	this->m_request->header.ack = 0;
	this->m_request->header.requestId = getReqId();
	this->m_request->header.blockNo = 0;
	memcpy(this->m_request->header.reserved2, reserved2, 8);
	this->m_request->sub_hdr.commandNo = 0x72;
	this->m_request->sub_hdr.instance = 0x0001;
	this->m_request->sub_hdr.attribute = 0x00;
	this->m_request->sub_hdr.service = 0x01;
	memset(this->m_request->sub_hdr.padding, 0, 2);
}

void CControlMessage::InitResponse()
{
	this->m_response = make_shared<RESPONSE_MESSAGE>();
}