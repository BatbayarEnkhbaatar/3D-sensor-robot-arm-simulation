#ifndef __UDPSOCKET_H__
#define __UDPSOCKET_H__

#include <stdint.h>
#include <WinSock2.h>
#include <string>

#include "etherfunc_exception.h"

using namespace std;

#pragma comment(lib, "ws2_32.lib")

#define SOCKBUF_LEN		4096

class CUdpSocketException : public CControllerException
{
public:
	CUdpSocketException() {}
	CUdpSocketException(string msg) : CControllerException(msg) {
	}

	CUdpSocketException(char* fmt, ...) {

		char buf[1024];

		va_list ap;

		va_start(ap, fmt);
		vsnprintf(buf, sizeof(buf), fmt, ap);
		va_end(ap);

		this->m_message = buf;
	}
};

class CUdpSocket
{
public:
	CUdpSocket(string host, uint16_t port);
	~CUdpSocket();

public:
	void SetTimeout(int32_t millis) {
		this->m_timeout = millis;
	}
	int32_t	GetTimeout() { return this->m_timeout;  }

	int SelectForRead();

	int SelectForWrite();

	int Select(bool* forRead);

	int Read(int8_t* buf, size_t bufsize);
	int Write(int8_t* buf, size_t nbytes);

	void Close();

	void CloseNetwork();
private:
	SOCKET		m_sock;
	string			m_host;
	uint16_t		m_port;
	sockaddr_in m_addr;

	static	bool m_wsaInitialized;

	// default timeout 10 secs
	int32_t		m_timeout = 10000;
};
#endif