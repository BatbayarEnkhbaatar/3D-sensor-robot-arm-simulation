#include "udpsocket.h"
#include <WS2tcpip.h>

bool CUdpSocket::m_wsaInitialized = false;

CUdpSocket::CUdpSocket(string host, uint16_t port) : 
    m_sock(INVALID_SOCKET),
    m_host(host),
    m_port(port)
{
    // WSA Initialize
    //
    if (CUdpSocket::m_wsaInitialized == false) {
        // initialise winsock
        WSADATA ws;
        printf("Initialising Winsock...");
        if (WSAStartup(MAKEWORD(2, 2), &ws) != 0)
        {
            throw CUdpSocketException((char*)"Failed. Error Code: %d", WSAGetLastError());
        }
        printf("Initialised.\n");

        CUdpSocket::m_wsaInitialized = true;
    }

    // Create SOCKET
    SOCKET client_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (client_socket == SOCKET_ERROR) {
        throw CUdpSocketException((char*)"socket() failed with error code: %d", WSAGetLastError());
    }

    this->m_sock = client_socket;

    // setup address structure
    //
    int rval;
    struct in_addr inaddr;
    if ((rval = inet_pton(AF_INET, this->m_host.c_str(), &inaddr)) == 0) {
        exit(EXIT_FAILURE);
    }

    memset((char*)&this->m_addr, 0, sizeof(this->m_addr));
    this->m_addr.sin_family = AF_INET;
    this->m_addr.sin_port = htons(this->m_port);
    this->m_addr.sin_addr.S_un.S_addr = inaddr.S_un.S_addr;
}

CUdpSocket::~CUdpSocket() {
    Close();
}

void CUdpSocket::Close() {
    if (this->m_sock != INVALID_SOCKET) {
        ::closesocket(this->m_sock);
        this->m_sock = INVALID_SOCKET;
    }
}

void CUdpSocket::CloseNetwork()
{
    int ret = ::WSACleanup();
}

int CUdpSocket::SelectForRead()
{
    struct timeval tv;
    fd_set readfds;

    FD_ZERO(&readfds);
    FD_SET(this->m_sock, &readfds);

    int32_t timeoutMillis = this->GetTimeout();
    tv.tv_sec = timeoutMillis / 1000;
    tv.tv_usec = (timeoutMillis % 1000) * 1000;

    int maxfd = (int)(this->m_sock + 1);
    int ret = select(maxfd, &readfds, NULL, NULL, &tv);

    if (ret == -1) {
        // select error
        throw  CUdpSocketException((char*)"select() failed with error code: %d", WSAGetLastError());
    }
    else if (ret == 0) {
        // timeout
        throw  CUdpSocketException("select() timed out");
    }

    if (FD_ISSET(this->m_sock, &readfds)) {
        return ret;
    }

    return ret;
}

int CUdpSocket::SelectForWrite()
{
    struct timeval tv;
    fd_set writefds;

    FD_ZERO(&writefds);
    FD_SET(this->m_sock, &writefds);

    int32_t timeoutMillis = this->GetTimeout();

    tv.tv_sec = timeoutMillis / 1000;
    tv.tv_usec = (timeoutMillis % 1000) * 1000;

    int maxfd = (int)(this->m_sock + 1);
    int ret = select(maxfd, NULL, &writefds, NULL, &tv);

    if (ret == -1) {
        // select error
        throw  CUdpSocketException((char*)"select() failed with error code: %d", WSAGetLastError());
    }
    else if (ret == 0) {
        // timeout
        throw  CUdpSocketException("select() timed out");
    }

    if (FD_ISSET(this->m_sock, &writefds)) {
        return ret;
    }

    return ret;
}

int CUdpSocket::Select(bool* forRead)
{
    struct timeval tv;
    fd_set readfds;
    fd_set writefds;

    FD_ZERO(&readfds);
    FD_ZERO(&writefds);
    FD_SET(this->m_sock, &readfds);
    FD_SET(this->m_sock, &writefds);

    int32_t timeoutMillis = this->GetTimeout();

    tv.tv_sec = timeoutMillis / 1000;
    tv.tv_usec = (timeoutMillis % 1000) * 1000;

    int maxfd = (int)(this->m_sock + 1);

    int ret = select(maxfd, &readfds, &writefds, NULL, &tv);

    if (ret == -1) {
        // select error
        throw  CUdpSocketException((char*)"select() failed with error code: %d", WSAGetLastError());
    }
    else if (ret == 0) {
        // timeout
        throw  CUdpSocketException("select() timed out");
    }

    if (FD_ISSET(this->m_sock, &readfds)) {
        *forRead = true;
        return ret;
    }
    if (FD_ISSET(this->m_sock, &writefds)) {
        *forRead = false;
        return ret;
    }

    return ret;
}

int CUdpSocket::Read(int8_t* buf, size_t bufsize)
{
    size_t addrlen = sizeof(this->m_addr);
    int recvlen = ::recvfrom(this->m_sock, (char*)buf, bufsize, 0, (SOCKADDR*)&this->m_addr, (int*) & addrlen);

    if (recvlen == SOCKET_ERROR) {
        throw CUdpSocketException((char*)"recvfrom failed wirth error code=%d", WSAGetLastError());
    }

    return recvlen;
}

int CUdpSocket::Write(int8_t* buf, size_t nbytes)
{
    int result = 0;

    // send the message
    int bytes_sent = sendto(this->m_sock, (char*)buf, nbytes, 0, (sockaddr*)&this->m_addr, sizeof(sockaddr_in));
    if (bytes_sent == SOCKET_ERROR)
    {
        throw CUdpSocketException((char*)"sendto() failed with error code: %d", WSAGetLastError());
    }

    return bytes_sent;
}
