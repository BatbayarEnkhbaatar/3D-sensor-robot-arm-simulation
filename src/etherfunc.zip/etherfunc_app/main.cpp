#include "etherfunc_exception.h"
#include "etherfunc_api.h"

#include <iostream>

using namespace std;

int main(int argc, char** argv)
{
	string host = "10.0.0.2";
	int16_t port = 10040;

	shared_ptr<CRobotController>	controller = make_shared<CRobotController>();

	try {
		int ret = controller->Init(host, port);
		//ret = controller->ReadStatus();

		if (0)
		{
			int index = 3;
			int8_t val = 128;

			// Write 100 at B003
			ret = controller->WriteByteValue(index, val);
			std::cout << "Succeeded in Write at B[" << std::to_string(index) << "] = " << std::to_string(val) << std::endl;

			// Read value from B003
			ret = controller->ReadByteValue(index, &val);
			std::cout << "Succeeded in Read at B[" << std::to_string(index) << "] = " << std::to_string(val) << std::endl;
		}

		if (1)
		{
			int index = 5;
			int32_t val = 123000;

			// Write 123000 at D005
			ret = controller->WriteDwordValue(index, val);
			std::cout << "Succeeded in Write at B[" << std::to_string(index) << "] = " << std::to_string(val) << std::endl;

			// Read value from D005
			ret = controller->ReadDwordValue(index, &val);
			std::cout << "Succeeded in Read at B[" << std::to_string(index) << "] = " << std::to_string(val) << std::endl;
		}

		if (0)
		{
			int		index = 0;
			// Write position (x, y, z, rx, ry, rz) = (100000, 100000, 100000, 300000, 450000, 300000) 
			//							= (10cm, 10cm, 10cm, 0, 0, 0)
			RobotCoordinate wcoord = { 345269, 141416, 372140, -1731761, -98745, -9607 };
			ret = controller->WritePosValue(index, &wcoord);

			std::cout << "Succeeded in Write (x, y, z, rx, ry, rz) at P[" << std::to_string(index) << "]  = (" <<
				std::to_string(wcoord.x) << ", " <<
				std::to_string(wcoord.y) << ", " <<
				std::to_string(wcoord.z) << ", " <<
				std::to_string(wcoord.rx) << ", " <<
				std::to_string(wcoord.ry) << ", " <<
				std::to_string(wcoord.rz) << ")" << std::endl;


			RobotCoordinate rcoord = {};
			ret = controller->ReadPosValue(index, &rcoord);
			std::cout << "Succeeded in Read (x, y, z, rx, ry, rz) at P[" << std::to_string(index) << "]  = (" <<
				std::to_string(rcoord.x) << ", " <<
				std::to_string(rcoord.y) << ", " <<
				std::to_string(rcoord.z) << ", " <<
				std::to_string(rcoord.rx) << ", " <<
				std::to_string(rcoord.ry) << ", " <<
				std::to_string(rcoord.rz) << ")" << std::endl;
		}

		if (0) {
			RobotCoordinate robotPos = {};
			ret = controller->ReadPosition(&robotPos);

			std::cout << "Succeeded in ReadPosition (x, y, z, rx, ry, rz) " << " = (" <<
				std::to_string(robotPos.x) << ", " <<
				std::to_string(robotPos.y) << ", " <<
				std::to_string(robotPos.z) << ", " <<
				std::to_string(robotPos.rx) << ", " <<
				std::to_string(robotPos.ry) << ", " <<
				std::to_string(robotPos.rz) << ")" << std::endl;

			int		index = 1;
			// Write position (x, y, z, rx, ry, rz) = (100000, 100000, 100000, 300000, 450000, 300000) 
			//							= (10cm, 10cm, 10cm, 0, 0, 0)
			ret = controller->WritePosValue(index, &robotPos);

			std::cout << "Succeeded in Write (x, y, z, rx, ry, rz) at P[" << std::to_string(index) << "]  = (" <<
				std::to_string(robotPos.x) << ", " <<
				std::to_string(robotPos.y) << ", " <<
				std::to_string(robotPos.z) << ", " <<
				std::to_string(robotPos.rx) << ", " <<
				std::to_string(robotPos.ry) << ", " <<
				std::to_string(robotPos.rz) << ")" << std::endl;


			RobotCoordinate rcoord = {};
			ret = controller->ReadPosValue(index, &rcoord);
			std::cout << "Succeeded in Read (x, y, z, rx, ry, rz) at P[" << std::to_string(index) << "]  = (" <<
				std::to_string(rcoord.x) << ", " <<
				std::to_string(rcoord.y) << ", " <<
				std::to_string(rcoord.z) << ", " <<
				std::to_string(rcoord.rx) << ", " <<
				std::to_string(rcoord.ry) << ", " <<
				std::to_string(rcoord.rz) << ")" << std::endl;
		}

		if (0) {
			// move 
			RobotCoordinate coord = { 345269, 141416, 372140, -1731761, -98745, -9607 };

			ret = controller->Move(coord);
		}
	}
	catch (CControllerException e) {
		std::cerr << "exception .what=" << e.what() << std::endl;
	}
	catch (std::exception e) {
		std::cerr << "exception .what=" << e.what() << std::endl;
	}
	catch (...) {
		std::cerr << "unknown exception occurrend" << std::endl;
	}
	

	return 0;
}