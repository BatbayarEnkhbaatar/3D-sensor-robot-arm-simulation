/*****************************************************************//**
 *  @file   robot_setting_dialog.cpp
 *  @copyright 4division
 *  @date   February 2024
 *  @author Kim jaemin
 *  @brief  RobotSettingDialog source file.
 *********************************************************************/
#include "pch.hpp"
#include "robot_setting_dialog.hpp"
#include "math/math_common.hpp"

namespace haanvision {
namespace binpicking {
namespace standalone {
namespace ui {

RobotSettingDialog::RobotSettingDialog( QWidget* parent )
    :QDialog( parent )
{
    setWindowFlags( Qt::Window | Qt::WindowCloseButtonHint );

    m_commonGroupWidget = new RobotCommonGroupWidget( this );
    m_toolGroupWidget = new RobotToolGroupWidget( this );
    m_positionGroupWidget = new RobotPositionGroupWidget( this );
    m_calibrationGroupWidget = new RobotCalibrationGroupWidget( this );

    m_robotWizard = new RobotCoordinateWizard( this );
    m_sensorWizard = new SensorCoordinateWizard( this );

    m_calibrationMatrix = cv::Mat::eye( 4, 4, CV_64F );

    installLayout();
    connectSignals();
}

void RobotSettingDialog::receive3dData( PointCloud pointcloud )
{
    if ( !isVisible() ) {
        return;
    }

    m_sensorWizard->receive3dData( pointcloud );
}

void RobotSettingDialog::installLayout( void )
{
    auto mainLayout = new QHBoxLayout();
    auto leftLayout = new QVBoxLayout();

    m_commonGroupWidget->installLayout();
    m_toolGroupWidget->installLayout();
    m_positionGroupWidget->installLayout();
    m_calibrationGroupWidget->installLayout();

    m_robotWizard->installLayout();
    m_sensorWizard->installLayout();

    leftLayout->addWidget( m_commonGroupWidget );
    leftLayout->addSpacerItem( new QSpacerItem( 0, 10 ) );
    leftLayout->addWidget( m_toolGroupWidget );
    leftLayout->addSpacerItem( new QSpacerItem( 0, 10 ) );
    leftLayout->addWidget( m_positionGroupWidget );
    leftLayout->addSpacerItem( new QSpacerItem( 0, 10, QSizePolicy::Minimum, QSizePolicy::Expanding ) );
    leftLayout->addWidget( m_applyButton );

    mainLayout->addLayout( leftLayout );
    mainLayout->addWidget( m_calibrationGroupWidget );

    setLayout( mainLayout );
}

void RobotSettingDialog::connectSignals( void ) const
{
    // This ui
    QObject::connect( m_applyButton, &QPushButton::clicked,
        this, &RobotSettingDialog::onApplyButtonClicked );

    // Common group
    QObject::connect( m_commonGroupWidget->getCheckConnectionButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onCheckConnectionButtonClicked );

    QObject::connect( m_commonGroupWidget->getMoveLeftButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onMoveLeftButtonClicked );

    QObject::connect( m_commonGroupWidget->getMoveRightButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onMoveRightButtonClicked );

    // Tool group
    QObject::connect( m_toolGroupWidget,
        &RobotToolGroupWidget::operationButtonClicked,
        this, &RobotSettingDialog::onToolOperationButtonClicked );

    // Position group
    QObject::connect( m_positionGroupWidget->getMoveToOriginPositionButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onMoveToOriginButtonClicked );

    QObject::connect( m_positionGroupWidget->getSetOriginPositionButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onSetOriginButtonClicked );

    QObject::connect( m_positionGroupWidget->getSetWaypointPositionButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onSetWaypointButtonClicked );

    // Calibration group
    QObject::connect( m_calibrationGroupWidget->getAcquireSensorCoordinateButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onAcquireSensorCoordinateButtonClicked );

    QObject::connect( m_calibrationGroupWidget->getAcquireRobotCoordinateButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onAcquireRobotCoordinateButtonClicked );

    QObject::connect( m_calibrationGroupWidget->getManualLoadCalibrationButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onManualLoadButtonClicked );

    QObject::connect( m_calibrationGroupWidget->getCalculateCalibrationButton(),
        &QPushButton::clicked,
        this, &RobotSettingDialog::onCaluclateButtonClicked );

    // Dialogs
    QObject::connect( m_robotWizard, &RobotCoordinateWizard::acquireDone,
        m_calibrationGroupWidget, &RobotCalibrationGroupWidget::onRobotCoordinatesAcquireDone );

    QObject::connect( m_sensorWizard, &SensorCoordinateWizard::acquireDone,
        m_calibrationGroupWidget, &RobotCalibrationGroupWidget::onSensorCoordinatesAcquireDone );
}

void RobotSettingDialog::showEvent( QShowEvent* event )
{
    auto robotProperty = controls::PropertyManager::getInstance()->getRobotProperty();
    auto coordinateProperty = controls::PropertyManager::getInstance()->getCoordinateProperty();

    m_commonGroupWidget->loadProperty( *robotProperty );
    m_positionGroupWidget->loadProperty( *robotProperty );
    m_calibrationGroupWidget->loadProperty( *coordinateProperty );

    // Fix some invalid properties
    s32_t minimumSpeed = m_commonGroupWidget->getMoveSpeedSpinBox()->minimum();
    s32_t maximumSpeed = m_commonGroupWidget->getMoveSpeedSpinBox()->maximum();

    if ( robotProperty->speed < minimumSpeed ) {
        robotProperty->speed = minimumSpeed;
    }

    if ( robotProperty->speed > maximumSpeed ) {
        robotProperty->speed = maximumSpeed;
    }

    m_calibrationMatrix = coordinateProperty->getHomogeneousMatrix();

    setMinimumSize( 1250, 450 );
}

void RobotSettingDialog::closeEvent( QCloseEvent* event )
{
}

void RobotSettingDialog::changeEvent( QEvent* event )
{
    switch ( event->type() ) {
    case QEvent::LanguageChange:
        setWindowTitle( tr( "title_robot_dialog" ) );

        m_commonGroupWidget->updateLocale();
        m_toolGroupWidget->updateLocale();
        m_positionGroupWidget->updateLocale();
        m_calibrationGroupWidget->updateLocale();

        m_applyButton->setText( tr( "apply" ) );
        break;
    default:
        QWidget::changeEvent( event );
        break;
    }
}

void RobotSettingDialog::onApplyButtonClicked( void )
{
    auto robotProperty = controls::PropertyManager::getInstance()->getRobotProperty();
    auto coordinateProperty = controls::PropertyManager::getInstance()->getCoordinateProperty();

    robotProperty->host = m_commonGroupWidget->getIpAddress();
    robotProperty->port = m_commonGroupWidget->getPort();
    robotProperty->speed = m_commonGroupWidget->getMoveSpeedSpinBox()->value();

    // origin
    robotProperty->originPosition = m_originPosition;

    // wayPoint
    robotProperty->waypointPosition.x = m_positionGroupWidget->getWaypointPosition( Coordinates::X );
    robotProperty->waypointPosition.y = m_positionGroupWidget->getWaypointPosition( Coordinates::Y );
    robotProperty->waypointPosition.z = m_positionGroupWidget->getWaypointPosition( Coordinates::Z );
    robotProperty->waypointPosition.rx = m_positionGroupWidget->getWaypointPosition( Coordinates::RX );
    robotProperty->waypointPosition.ry = m_positionGroupWidget->getWaypointPosition( Coordinates::RY );
    robotProperty->waypointPosition.rz = m_positionGroupWidget->getWaypointPosition( Coordinates::RZ );
    robotProperty->waypointLength = m_positionGroupWidget->getLength();

    // Tool
    coordinateProperty->tools.length = m_calibrationGroupWidget->getToolLength();
    coordinateProperty->tools.sx = m_calibrationGroupWidget->getToolSx();
    coordinateProperty->tools.sy = m_calibrationGroupWidget->getToolSy();

    // Coordinates
    coordinateProperty->robotCoordinates = m_calibrationGroupWidget->getRobotCoordinates();
    coordinateProperty->sensorCoordinates = m_calibrationGroupWidget->getSensorCoordinates();

    // calibration matrix
    for ( u08_t i = 0; i < 4; ++i ) {
        for ( u08_t j = 0; j < 4; ++j ) {
            coordinateProperty->homogeneousMatrix[i][j] = m_calibrationMatrix.at<r64_t>( i, j );
        }
    }

    QMessageBox messageBox;
    messageBox.setStandardButtons( QMessageBox::Yes );

    if ( !controls::PropertyManager::getInstance()->saveCoordinate() ) {
        messageBox.setWindowTitle( tr( "save_title_failed" ) );
        messageBox.setText( coordinateProperty->filePath + tr( "save_failed" ) );
    }

    if ( !controls::PropertyManager::getInstance()->saveRobot() ) {
        messageBox.setWindowTitle( tr( "save_title_failed" ) );
        messageBox.setText( robotProperty->filePath + tr( "save_failed" ) );
    }

    messageBox.exec();
}

void RobotSettingDialog::onCheckConnectionButtonClicked( void )
{
    auto host = m_commonGroupWidget->getIpAddress().toStdString();
    auto port = m_commonGroupWidget->getPort();

    auto controller = make_shared<CRobotController>();
    RobotCoordinate robotPosition;

    int ret = 0;
    bool ok = false;

    m_commonGroupWidget->getCheckConnectionButton()->setEnabled( false );
    m_commonGroupWidget->setConnectionMessage( tr( "check_robot_connection" ) );

    QApplication::processEvents();

    try {
        // Init controller
        ret = controller->Init( host, port );

        // read current robot position (x, y, z, rx, rz, rz)
        ret = controller->ReadPosition( &robotPosition );

        std::cout << "Succeeded in ReadPosition (x, y, z, rx, ry, rz) " << " = (" <<
            std::to_string( robotPosition.x ) << ", " <<
            std::to_string( robotPosition.y ) << ", " <<
            std::to_string( robotPosition.z ) << ", " <<
            std::to_string( robotPosition.rx ) << ", " <<
            std::to_string( robotPosition.ry ) << ", " <<
            std::to_string( robotPosition.rz ) << ")" << std::endl;

        ok = true;
    }
    catch ( CControllerException e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( std::exception e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( ... ) {
        std::cerr << "unknown exception occurrend" << std::endl;
    }

    if ( ok ) {
        m_commonGroupWidget->getLedIndicator()->setState( true );
        m_commonGroupWidget->setConnectionMessage( tr( "robot_connection_ok" ) );
    }
    else {
        m_commonGroupWidget->getLedIndicator()->setState( false );
        m_commonGroupWidget->setConnectionMessage( tr( "robot_connection_error" ) );
    }

    m_commonGroupWidget->getCheckConnectionButton()->setEnabled( true );
}

void RobotSettingDialog::onMoveLeftButtonClicked( void )
{
    auto host = m_commonGroupWidget->getIpAddress().toStdString();
    auto port = m_commonGroupWidget->getPort();
    auto speed = m_commonGroupWidget->getMoveSpeedSpinBox()->value();

    auto controller = make_shared<CRobotController>();
    RobotCoordinate robotPosition;

    int ret = 0;

    try {
        // Init controller
        ret = controller->Init( host, port );

        // read current robot position (x, y, z, rx, rz, rz)
        ret = controller->ReadPosition( &robotPosition );

        std::cout << "Succeeded in ReadPosition (x, y, z, rx, ry, rz) " << " = (" <<
            std::to_string( robotPosition.x ) << ", " <<
            std::to_string( robotPosition.y ) << ", " <<
            std::to_string( robotPosition.z ) << ", " <<
            std::to_string( robotPosition.rx ) << ", " <<
            std::to_string( robotPosition.ry ) << ", " <<
            std::to_string( robotPosition.rz ) << ")" << std::endl;

        // Move left by 10 centimeter
        robotPosition.x -= 100000;

        ret = controller->Move( robotPosition, speed );
    }
    catch ( CControllerException e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( std::exception e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( ... ) {
        std::cerr << "unknown exception occurrend" << std::endl;
    }
}

void RobotSettingDialog::onToolOperationButtonClicked( s16_t instance, u08_t value )
{
    // TODO: implement io data when needed... this method will not work currently.
    return;

    auto host = m_commonGroupWidget->getIpAddress().toStdString();
    auto port = m_commonGroupWidget->getPort();

    auto controller = make_shared<CRobotController>();
    RobotCoordinate robotPosition;

    int ret = 0;

    try {
        // Init controller
        ret = controller->Init( host, port );

        // Execute(operate) tool
        //ret = controller->WriteIoData( instance, value );
    }
    catch ( CControllerException e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( std::exception e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( ... ) {
        std::cerr << "unknown exception occurrend" << std::endl;
    }
}

void RobotSettingDialog::onMoveRightButtonClicked( void )
{
    auto host = m_commonGroupWidget->getIpAddress().toStdString();
    auto port = m_commonGroupWidget->getPort();
    auto speed = m_commonGroupWidget->getMoveSpeedSpinBox()->value();

    auto controller = make_shared<CRobotController>();
    RobotCoordinate robotPosition;

    int ret = 0;

    try {
        // Init controller
        ret = controller->Init( host, port );

        // read current robot position (x, y, z, rx, rz, rz)
        ret = controller->ReadPosition( &robotPosition );

        std::cout << "Succeeded in ReadPosition (x, y, z, rx, ry, rz) " << " = (" <<
            std::to_string( robotPosition.x ) << ", " <<
            std::to_string( robotPosition.y ) << ", " <<
            std::to_string( robotPosition.z ) << ", " <<
            std::to_string( robotPosition.rx ) << ", " <<
            std::to_string( robotPosition.ry ) << ", " <<
            std::to_string( robotPosition.rz ) << ")" << std::endl;

        // Move left by 10 centimeter
        robotPosition.x += 100000;

        ret = controller->Move( robotPosition, speed );
    }
    catch ( CControllerException e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( std::exception e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( ... ) {
        std::cerr << "unknown exception occurrend" << std::endl;
    }
}

void RobotSettingDialog::onMoveToOriginButtonClicked( void )
{
    auto host = m_commonGroupWidget->getIpAddress().toStdString();
    auto port = m_commonGroupWidget->getPort();
    auto speed = m_commonGroupWidget->getMoveSpeedSpinBox()->value();

    auto controller = make_shared<CRobotController>();
    RobotCoordinate robotPosition = controls::PropertyManager::getInstance()->getRobotProperty()->originPosition;

    try {

        int ret = controller->Init( host, port );

        int tries = 0;
        QString s;

        // Target Pos 로 이동
        ret = controller->Move( robotPosition, speed );

        emit sendMessage( LogLevel::info, tr( "Move to origin position: (%1, %2, %3, %4, %5, %6)" )
            .arg( robotPosition.x )
            .arg( robotPosition.y )
            .arg( robotPosition.z )
            .arg( robotPosition.rx )
            .arg( robotPosition.ry )
            .arg( robotPosition.rz ), HV_METHOD, __LINE__ );
    }
    catch ( CControllerException e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( std::exception e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( ... ) {
        std::cerr << "unknown exception occurrend" << std::endl;
    }
}

void RobotSettingDialog::onSetOriginButtonClicked( void )
{
    auto host = m_commonGroupWidget->getIpAddress().toStdString();
    auto port = m_commonGroupWidget->getPort();

    auto controller = make_shared<CRobotController>();
    RobotCoordinate robotPosition;

    int ret = 0;

    try {
        // Init controller
        ret = controller->Init( host, port );

        // read current robot position (x, y, z, rx, rz, rz)
        ret = controller->ReadPosition( &robotPosition );

        std::cout << "Succeeded in ReadPosition (x, y, z, rx, ry, rz) " << " = (" <<
            std::to_string( robotPosition.x ) << ", " <<
            std::to_string( robotPosition.y ) << ", " <<
            std::to_string( robotPosition.z ) << ", " <<
            std::to_string( robotPosition.rx ) << ", " <<
            std::to_string( robotPosition.ry ) << ", " <<
            std::to_string( robotPosition.rz ) << ")" << std::endl;

        // Save
        m_originPosition = robotPosition;

        m_positionGroupWidget->setOriginPositionCoordinate( m_originPosition );
    }
    catch ( CControllerException e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( std::exception e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( ... ) {
        std::cerr << "unknown exception occurrend" << std::endl;
    }
}

void RobotSettingDialog::onSetWaypointButtonClicked( void )
{
    auto host = m_commonGroupWidget->getIpAddress().toStdString();
    auto port = m_commonGroupWidget->getPort();
    auto speed = m_commonGroupWidget->getMoveSpeedSpinBox()->value();

    auto controller = make_shared<CRobotController>();
    RobotCoordinate robotPosition;

    int ret = 0;

    try {
        // Init controller
        ret = controller->Init( host, port );

        // read current robot position (x, y, z, rx, rz, rz)
        ret = controller->ReadPosition( &robotPosition );

        std::cout << "Succeeded in ReadPosition (x, y, z, rx, ry, rz) " << " = (" <<
            std::to_string( robotPosition.x ) << ", " <<
            std::to_string( robotPosition.y ) << ", " <<
            std::to_string( robotPosition.z ) << ", " <<
            std::to_string( robotPosition.rx ) << ", " <<
            std::to_string( robotPosition.ry ) << ", " <<
            std::to_string( robotPosition.rz ) << ")" << std::endl;


        // Save
        m_waypointPosition = robotPosition;

        m_positionGroupWidget->setWaypointPositionCoordinate( m_waypointPosition );
    }
    catch ( CControllerException e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( std::exception e ) {
        std::cerr << "exception .what=" << e.what() << std::endl;
    }
    catch ( ... ) {
        std::cerr << "unknown exception occurrend" << std::endl;
    }
}

void RobotSettingDialog::onAcquireSensorCoordinateButtonClicked( void )
{
    m_sensorWizard->initialize();
    m_sensorWizard->exec();
}

void RobotSettingDialog::onAcquireRobotCoordinateButtonClicked( void )
{
    auto host = m_commonGroupWidget->getIpAddress();
    auto port = m_commonGroupWidget->getPort();

    m_robotWizard->initialize( host, port );
    m_robotWizard->exec();
}

void RobotSettingDialog::onManualLoadButtonClicked( void )
{
    QString filePath = QFileDialog::getOpenFileName( this,
        tr( "select_file" ),
        QDir::currentPath(),
        "Files (*.*)" );

    qDebug() << filePath;

    QFile file( filePath );
    if ( !file.open( QFile::ReadOnly | QFile::Text ) ) {
        ui::showErrorPopup( tr( "warning" ), tr( "file_not_exists" ) );
    }
    else {
        QTextStream ts( &file );

        u08_t row = 0;

        while ( !ts.atEnd() ) {
            QString line = ts.readLine().trimmed();
            if ( line.isEmpty() ) {
                break;
            }

            std::istringstream iss( line.toLocal8Bit().constData() );
            std::vector<std::string> tokens;

            std::copy( std::istream_iterator<std::string>( iss ), std::istream_iterator<std::string>(),
                std::back_inserter( tokens ) );

            for ( u08_t col = 0; col < 4; ++col ) {
                m_calibrationMatrix.at<r64_t>( row, col )
                    = QString( tokens[col].c_str() ).toDouble();
            }

            ++row;
        }

        emit sendMessage( LogLevel::info, tr( "load_calibration_done" ), HV_METHOD, __LINE__ );

        for ( row = 0; row < 4; ++row ) {
            emit sendMessage( LogLevel::debug, QString( "%1, %2, %3, %4" )
                .arg( m_calibrationMatrix.at<r64_t>( row, 0 ) )
                .arg( m_calibrationMatrix.at<r64_t>( row, 1 ) )
                .arg( m_calibrationMatrix.at<r64_t>( row, 2 ) )
                .arg( m_calibrationMatrix.at<r64_t>( row, 3 ) ), HV_METHOD, -1 );
        }
    }
}

void RobotSettingDialog::onCaluclateButtonClicked( void )
{
    const auto robotCoordinates = m_calibrationGroupWidget->getRobotCoordinates();
    const auto sensorCoordinates = m_calibrationGroupWidget->getSensorCoordinates();

    auto rm = cv::Mat( m_calibrationGroupWidget->getRobotCoordinates().size(), 6, CV_64F );
    auto sm = cv::Mat( m_calibrationGroupWidget->getRobotCoordinates().size(), 3, CV_64F );

    auto toolMatrix = cv::Mat( 3, 1, CV_64F );
    toolMatrix.at<r64_t>( 0, 0 ) = m_calibrationGroupWidget->getToolSx();
    toolMatrix.at<r64_t>( 1, 0 ) = m_calibrationGroupWidget->getToolSy();
    toolMatrix.at<r64_t>( 2, 0 ) = m_calibrationGroupWidget->getToolLength();

    for ( s32_t row = 0; row < robotCoordinates.size(); ++row ) {
        rm.at<r64_t>( row, 0 ) = robotCoordinates[row].x / 1000.0;
        rm.at<r64_t>( row, 1 ) = robotCoordinates[row].y / 1000.0;
        rm.at<r64_t>( row, 2 ) = robotCoordinates[row].z / 1000.0;
        rm.at<r64_t>( row, 3 ) = robotCoordinates[row].rx / 10000.0;
        rm.at<r64_t>( row, 4 ) = robotCoordinates[row].ry / 10000.0;
        rm.at<r64_t>( row, 5 ) = robotCoordinates[row].rz / 10000.0;
    }

    for ( s32_t row = 0; row < sensorCoordinates.size(); ++row ) {
        sm.at<r64_t>( row, 0 ) = sensorCoordinates[row].x;
        sm.at<r64_t>( row, 1 ) = sensorCoordinates[row].y;
        sm.at<r64_t>( row, 2 ) = sensorCoordinates[row].z;
    }

    math::getHomogeneousMatrix( rm, sm, toolMatrix, &m_calibrationMatrix );
}

}   // namespace ui
}   // namespace standalone
}   // namespace binpicking
}   // namespace haanvision
