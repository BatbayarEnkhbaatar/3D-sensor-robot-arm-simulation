#!/usr/bin/env python3
"""
trigger_gripper_job.py

A minimal script that simply selects and runs an existing JBI job once,
then exits with code 0 on success or 1 on failure. All “extra” steps (servo on/off,
status polling, verbose prints) have been removed.

Usage:
    python3 trigger_gripper_job.py
"""

import sys

# ─── EDIT THESE TWO LINES ─────────────────────────────────────────────────────────→
ROBOT_IP = "10.0.0.2"   # ←– Change to your FS100 controller’s IP
JOB_NAME  = "DEM2"        # ←– Change to the exact job name (no “.JBI” extension)
# ────────────────────────────────────────────────────────────────────────────────←

try:
    from fs100 import FS100, FS100 as FS
except ImportError:
    print("ERROR: Cannot find fs100.py.  Make sure it's in the same folder.", file=sys.stderr)
    sys.exit(1)


def main():
    fs = FS100(ROBOT_IP)

    # 1) Select the job
    if fs.select_job(JOB_NAME) != FS.ERROR_SUCCESS:
        print(f"ERROR: select_job('{JOB_NAME}') failed (err=0x{fs.errno:X})", file=sys.stderr)
        sys.exit(1)

    # 2) Set cycle to ONE_CYCLE
    if fs.select_cycle(FS.CYCLE_TYPE_ONE_CYCLE) != FS.ERROR_SUCCESS:
        print("ERROR: select_cycle(ONE_CYCLE) failed (err=0x{fs.errno:X})".format(fs.errno), file=sys.stderr)
        sys.exit(1)

    # 3) Play the job
    if fs.play_job() != FS.ERROR_SUCCESS:
        print("ERROR: play_job() failed (err=0x{fs.errno:X})".format(fs.errno), file=sys.stderr)
        sys.exit(1)

    # If we reach here, all three calls succeeded
    print("Job triggered successfully.")
    sys.exit(0)


if __name__ == "__main__":
    main()
